import collections
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/Users/majid/www/barghsa/barghsa-core')
out = Path('/tmp/barghsa-completion-sprint')
audit = root / 'audit'
evidence = audit / 'evidence/completion-sprint'
evidence.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text())

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['rtk', 'proxy', 'git', *args], cwd=root, text=True).strip()

coverage = read(out / 'final-coverage.json')
assert coverage['status'] == 'passed' and not coverage['errors']
assert '769 passed' in (out / 'browser-closure.log').read_text()
assert (out / 'image-runtime-final.log').read_text().count('PASS ') == 4
browser_revision = coverage['head_sha']
revision = git('rev-parse', 'HEAD')
reuse = read(out / 'final-revision-reuse.json')
assert reuse['browser_revision'] == browser_revision and reuse['final_revision'] == revision and reuse['production_source_equal'] is True
write(audit / 'combined-coverage-checkpoint.json', coverage)

closure = read(audit / 'acceptance-closure.json')
coverage_key = '01-platform-infrastructure.md#T-01.04.02'
coverage_row = next(row for row in closure['reviewed_tasks'] if row['task_key'] == coverage_key)
old_coverage_row = json.loads(json.dumps(coverage_row))
coverage_row.update(status='acceptance_verified', reviewed_sha=revision,
                    checks=['All changed-code coverage groups pass the unchanged 80/75 general and 90/85 critical gates; no missing or invalid counters.',
                            'Browser coverage comes from a clean committed checkout and a complete passing Chromium suite with source-preserving coverage minification settings; the optimized production build independently passes the same suite. Unit evidence and source-byte equivalence are retained.',
                            'The combined diff-aware checker enforces critical floors in addition to native package coverage thresholds. No exception, exclusion or classifier change was introduced by this sprint.'],
                    limitations=[])
for entry in coverage_row['source_evidence']:
    entry['sha256'] = sha(root / entry['path'])
if not (evidence / 'coverage-acceptance-history.json').exists():
    write(evidence / 'coverage-acceptance-history.json', {'previous': old_coverage_row, 'current_revision': revision})
write(audit / 'acceptance-closure.json', closure)
counts = collections.Counter(row['status'] for row in closure['reviewed_tasks'])

progress = read(audit / 'progress.json')
progress.update(updated='2026-09-20', status='local_repair_complete', source_revision=revision,
                active_step='B01', next_action='Local repair sprint complete. Use the skipped-work handoff and exact partial criteria for separately authorized future work; no further serial repair batches.')
progress['counts']['acceptance_verified'] = counts['acceptance_verified']
progress['counts']['partial'] = counts['partial']
for step in progress['steps']:
    if step['id'] in {'V01', 'R06', 'V02', 'B01'}:
        step['status'] = 'completed'
        step.pop('remaining', None)
progress['active_batch'].update(status='completed_locally', source_revision=revision)
progress['completion_sprint'].update(status='completed_locally', source_revision=revision,
                                    next_action=progress['next_action'], coverage_thresholds_changed=False)
progress['evidence_refresh_queue'] = []
for group in progress['groups']:
    if group['id'] == 'F19':
        group.update(acceptance_status='local_task_verified', remaining=['All unchanged combined coverage gates and local build/type/lint/format/contract/budget checks pass. Hosted CI and deployment remain separate evidence.'])
    elif group['id'] in {'F11', 'F16'}:
        group.update(acceptance_status='local_task_verified', remaining=['Current implemented workflows pass the complete production-browser suite. Unbuilt consumers remain assigned to their separate tasks.'])
    elif group['id'] == 'F18':
        group['remaining'] = ['Current production images pass local boot, migration, readiness, shutdown and retry tests. Node24 requirement decision, release tags, rollout and real backing-service proof remain external.']
    elif group['id'] == 'F20':
        group['remaining'] = ['Current localization, RTL, calendar, theme and accessibility behavior passes production-browser regression. Unbuilt theme-editor/per-user controls and the literal Base UI versus Radix requirement remain explicit.']
    elif group['id'] == 'F22':
        group.update(acceptance_status='disposition_complete', remaining=['All 322 claims and 301 saved PRs have explicit dispositions, with no pending review or stale source binding. Partial/deferred criteria are retained; this does not certify unbuilt or external work.'])
progress['deferred_improvements'] = [row for row in progress['deferred_improvements'] if 'test-production-images.py' not in row.get('issue', '')]
for review in progress['open_domain_reviews']:
    if not isinstance(review, dict):
        continue
    if 'pending linked acceptance' in review.get('status', ''):
        review['status'] = 'Dispositioned in current acceptance ledger; complete future contract/document consumers remain prerequisites.' if 'contracts' in review.get('owner_batch', '') else 'Current local delivery reviewed; signed-webhook policy remains the recorded owner prerequisite.'
    if 'Chargeback review follows' in review.get('status', ''):
        review['status'] = 'Browser return and chargeback authentication/replay are reviewed and tested; signed-provider CSRF wording awaits owner decision.'
write(audit / 'progress.json', progress)

steps = read(audit / 'evidence/step-reviews.json')
step = next(row for row in steps['steps'] if row['id'] == 'V01-completion-sprint')
step.update(source_revision=revision, status='completed_locally',
            product_commits=git('rev-list', '--reverse', '08f97589..HEAD').splitlines())
step['task_keys'] = list(dict.fromkeys(step['task_keys'] + [coverage_key]))
for disposition in step['pr_dispositions']:
    disposition['source_revision'] = revision
    if disposition['pr'] == 16:
        disposition.update(status='closed', reason='All unchanged combined coverage thresholds now pass with complete source-bound evidence and no checker errors.')
step['verification'] = ['Local completion checkpoint passed; full browser769/769, worker 458/458 and unchanged coverage gates. API full5019-case run had two timing-fixture failures, both corrected and covered by a103-case passing rerun; new boundary tests288-case plus updated114-case run pass, with overlap.',
                        'Full remaining package suites, clean frozen install/build, typecheck, lint, formatting, contract, route budgets, migration snapshot and tooling/loop tests pass; exact logs and revision reuse are in final-repair-checkpoint.json.',
                        'Earlier failures are preserved alongside fixes and passing reruns. No hosted CI, production/provider delivery or rollout is claimed.']
step['review'].append('Final static follow-up at09117d73 found no blockers in pending-response draining or new boundary assertions. Conservative conversion keeps every unmeasurable branch arm uncovered and retains raw data. SMS scroll groups use the existing documented keyboard-scroll accessibility pattern.')
source_paths = set(git('diff', '--name-only', '08f97589..HEAD').splitlines())
source_paths.update(read(out / 'source-refresh-unmapped.json'))
source_paths.update(['packages/shared/src/errors/domain-error-codes.ts', 'apps/api/src/common/http-exception.filter.ts', 'audit/combined-coverage-checkpoint.json'])
source_paths.discard('apps/api/src/common/public-domain-error-codes.ts')
step['source_evidence'] = [{'path': p, 'sha256': sha(root / p)} for p in sorted(source_paths) if (root / p).is_file() and (not p.startswith('audit/') or p == 'audit/combined-coverage-checkpoint.json')]

checkpoint = {
    'schema_version': 1, 'date': '2026-09-20', 'runtime_revision': revision,
    'branch': 'codex/audit-fixes', 'scope': 'Completed actionable local audit repairs and review dispositions under the approved consolidated sprint. Future features, owner decisions and external operational proof remain explicitly open.',
    'remote_actions_performed': False,
    'repairs': ['Commit-time session/permission/step-up checks for administration mutations.', 'Audited/versioned geography mutations, protected city deactivation, bilingual city management and atomic bulk import.', 'Stable keyset paging and transactional escalation/breach scans beyond the first500 records.', 'Keyboard-scrollable SMS tables; current regression fixtures, deterministic expiry and live-navigation synchronization.'],
    'regression': {
        'api': {'full_revision': 'd7eccb05c25213577d527d4f5644dd1c6f2b273b', 'full_passed': 5017, 'full_failed': 2, 'full_total': 5019, 'resolution': 'Both failures were same-millisecond/expiry fixture timing. Deterministic audit-trigger expiry and the103-case approval rerun pass. API production source bytes are unchanged. New boundary suite288 passes; final extended two-file suite114 passes. Counts overlap and are not added as distinct tests.', 'logs': ['final-api2.log', 'api-expiry-final.log', 'coverage-new-api3.log', 'coverage-new-api5.log']},
        'worker': {'passed': 458, 'files': 37, 'log': 'worker-final-coverage.log'},
        'other_packages': {'db': 760, 'shared': 976, 'web': 777, 'ui': 58, 'i18n': 50, 'tsconfig': 3},
        'reuse': 'Unchanged package source retains its full-suite evidence. API full+focused reports are merged by original branch identity; relocated paths require identical source bytes. Raw reports and provenance are archived.'
    },
    'browser': {'status': 'passed', 'tests': 769, 'project': 'chromium', 'build': 'production mode with minification disabled only for source coverage', 'working_tree_dirty': False, 'source_revision': browser_revision, 'log': 'browser-closure.log', 'optimized_production': {'tests': 769, 'status': 'passed', 'source_revision': '17a50381b29866f6ff83c1b26d748dd53172ffaa', 'log': 'browser-optimized.log'}, 'measurement_review': 'The collector now includes /auth/assets with identical source/range checks. Coverage-only minify:false preserves statement boundaries; a fresh full browser execution supplies all counts. Optimized ranges are not reused against unminified code.'},
    'checks': {'frozen_install': 'passed', 'production_build': 'passed', 'workspace_typecheck': 'passed (11 tasks)', 'lint': 'passed', 'format': 'passed', 'suppressed_errors': 'passed after preserving three old ignored September13 distribution-test temporary folders outside production scan roots', 'openapi_contract': 'passed', 'route_budgets': 'passed, numeric limits unchanged', 'migration_snapshot': 'passed', 'script_python_loop_tests': 'passed', 'source_binding_refresh': 'Current source bindings refreshed with prior hashes retained; measurement and coverage bindings separately reviewed'},
    'coverage': {'status': 'passed', 'passed_groups': len(coverage['groups']), 'total_groups': len(coverage['groups']), 'thresholds_changed': False, 'exception_granted': False, 'errors': [], 'base_sha': coverage['base_sha'], 'report': 'audit/combined-coverage-checkpoint.json', 'provenance': 'audit/evidence/completion-sprint/final-unit-coverage-provenance.json.gz', 'measurement_note': 'Impossible negative converted worker and browser branches retain all their arms uncovered; raw values are preserved. No branch denominator is reduced.'},
    'historical_acceptance': {'verified': counts['acceptance_verified'], 'partial': counts['partial'], 'deferred': counts['deferred'], 'pending': 0, 'total': 322},
    'production_images': {'status': 'local_build_and_runtime_checks_passed', 'api_worker_source_revision': 'd4cc0193', 'web_source_revision': '17a50381b29866f6ff83c1b26d748dd53172ffaa', 'reuse': 'No API/worker/shared/DB production source changed after the recorded API/worker image build; only tests and coverage tooling changed. Web image includes final UI repairs; the subsequent measurement-only minify condition leaves normal production minification unchanged.', 'images': read(out / 'final-image-identities.json'), 'log': 'image-runtime-final.log', 'checks': ['Non-root/read-only boot, packaged migrations, optional Redis fallback', 'Database outage/recovery changes readiness, preserves liveness', 'SIGTERM drains notification and finance commits', 'Forced deadline preserves retryable work; restart commits once; web/API shutdown'], 'pushed': False},
    'evidence_directory': 'audit/evidence/completion-sprint', 'previous_checkpoint': 'audit/evidence/completion-sprint/previous-final-repair-checkpoint.json.gz',
    'external_and_deferred_details': ['audit/HANDOFF.md', 'audit/skipped-work-handoff.md', 'audit/acceptance-closure.json'],
    'budget': {'weekly_used_baseline': 0, 'latest_account_used_percent': progress['completion_sprint']['latest_weekly_used_percent'], 'stop_target': 45, 'ceiling': 50, 'note': 'Account-wide meter, not a per-task token count.'}
}
write(audit / 'final-repair-checkpoint.json', checkpoint)

index = read(audit / 'evidence/index.json')
existing = {row['original_path'] for row in index['logs']}
selected = sorted([p for p in out.iterdir() if p.is_file() and p.suffix in {'.log', '.json', '.md', '.py'}])
for source in selected:
    if str(source) in existing:
        continue
    target = evidence / (source.name + '.gz')
    raw = source.read_bytes()
    target.write_bytes(gzip.compress(raw, mtime=0))
    index['logs'].append({'original_path': str(source), 'path': str(target.relative_to(root)), 'sha256': hashlib.sha256(raw).hexdigest(), 'encoding': 'gzip', 'stored_sha256': sha(target)})
step['logs'] = [str(p) for p in selected if p.suffix == '.log']
write(audit / 'evidence/index.json', index)
write(audit / 'evidence/step-reviews.json', steps)
print('Finalized', dict(counts), 'coverage groups', len(coverage['groups']), 'saved evidence files', len(selected))
