import subprocess,json,time,pathlib
root=pathlib.Path('/Users/majid/.codex/worktrees/audit-completion-check/barghsa-core')
out=pathlib.Path('/tmp/barghsa-completion-sprint')
commands=[('types',['pnpm','typecheck']),('lint',['pnpm','lint']),('format',['pnpm','format:check']),('suppressed',['pnpm','check:suppressed-errors']),('contract',['pnpm','check:contract']),('bundle',['pnpm','check:bundle']),('db-snapshot',['pnpm','check:db-snapshot'])]
commands += [(f'coverage-{name}',['pnpm','--filter',f'@barghsa/{name}','test:coverage']) for name in ['api','worker','db','shared','web','ui','i18n','tsconfig']]
commands += [('script-tests',['node','--test',*map(str,root.glob('scripts/*.test.mjs'))]),('python-tests',['python3','-m','unittest','discover','-s','scripts','-p','test_*.py']),('loop-tests',['python3','-m','unittest','discover','-s','kanban/scripts','-p','test_*.py'])]
results=[]
for name,cmd in commands:
 start=time.time()
 with (out/f'final-{name}.log').open('w') as log:
  proc=subprocess.run(['rtk','proxy',*cmd],cwd=root,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(name=name,command=cmd,exit_code=proc.returncode,seconds=round(time.time()-start,1),log=str(out/f'final-{name}.log')))
 (out/'validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,proc.returncode,flush=True)
