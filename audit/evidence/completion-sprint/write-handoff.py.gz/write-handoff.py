import json
from pathlib import Path
root=Path('/Users/majid/www/barghsa/barghsa-core');audit=root/'audit'
checkpoint=json.loads((audit/'final-repair-checkpoint.json').read_text())
assert checkpoint['coverage']['status']=='passed'
rev=checkpoint['runtime_revision'];c=checkpoint['historical_acceptance'];weekly=checkpoint['budget']['latest_account_used_percent']
plan=f'''# Local repair completion

The consolidated repair sprint is complete at `{rev}`. [Final checkpoint](final-repair-checkpoint.json) records validation, revisions and evidence reuse. [Progress](progress.json) retains all 23 original repair groups. This replaces the serial feature-batch plan; archived plans remain historical evidence.

## Result

| Population | Verified/closed | Partial/open | Deferred | Pending/unreviewed |
| --- | ---: | ---: | ---: | ---: |
| 322 historical claims | {c['verified']} | {c['partial']} | {c['deferred']} | 0 |
| 301 saved merged PRs | 242 | 59 | — | 0 |
| 58 historical skips | 8 | 1 | 49 | 0 |

These are local audit dispositions, not a claim that every feature is implemented. All partial and deferred requirements retain their exact unmet criteria in [acceptance](acceptance-closure.json) and [skipped-work handoff](skipped-work-handoff.md). The saved GitHub inventory ends September 3; no fresh remote inventory or hosted CI result is claimed.

## Repairs completed

- Administration mutations retain current session, permission and required step-up authority through commit.
- Geography changes are transactional, versioned and audited. Referenced cities cannot be deactivated through either mutation path. Persian/English city management and bounded atomic bulk import are implemented.
- Support breach/escalation scans use stable paging and process records beyond the first 500 without repeatedly starving later records.
- Scrollable SMS tables support keyboard access. Regression fixtures follow current CSRF, session, product-key and UI contracts; expiry and navigation races have deterministic checks.
- Coverage meets the original general 80% lines/75% branches and critical 90%/85% thresholds. No floor, exclusion or critical-file classifier was relaxed.

## Acceptance evidence

The optimized production build passes all769 browser tests; the separate clean, unminified coverage build passes the same769 tests. The collector includes both application and dedicated authentication assets. Worker458, database 760, shared 976, web777, UI 58, i18n 50 and configuration3 unit/integration tests pass. The full API run passed5017 of5019; its two timing-fixture failures were repaired and the affected103-case suite passes. Additional boundary runs pass288 cases and an extended114-case subset; these overlap and must not be added as distinct totals.

Frozen installation, production builds,11 workspace typechecks, lint, formatting, contract, route budgets, migration snapshot and tooling/loop checks pass. Actual local production images pass packaged migration/boot, readiness recovery, graceful drain and retry-after-deadline tests. [Coverage report](combined-coverage-checkpoint.json) and [evidence index](evidence/index.json) retain exact results, earlier failures, original measurements and source hashes. Invalid negative converted worker/browser branches retain all arms as uncovered; it earns no coverage credit.

One combined independent review found a city deactivation bypass, which was fixed and regression-tested. Focused follow-ups found no remaining blockers. Prior source bindings are retained in [source refresh evidence](evidence/completion-sprint/source-refresh.json).

## Remaining prerequisites

1. Owner decisions already recorded: lost-contact recovery approval/evidence policy; signed-provider callback and native CSP-report CSRF wording;38 base-column design exceptions; Node24 versus literal Node20; Base UI/base-nova versus literal Radix/new-york. Do not silently waive or repeatedly reask these.
2. Future consumers/features: consultation assignment/targets; full ordering submission and green snapshots; contract/document workflows; after-payment cancellation/refunds; remaining reconciliation producers/navigation; deferred UI controls. Their task dependencies remain in the ledger.
3. Deployment evidence: credentials, real provider delivery, production inventory, TLS/proxy/firewall, backup/restore/RPO/RTO/load, monitoring delivery, installed schedules, rollout and recovery. Local tests do not certify these.
4. Remote loop bootstrap/PR304 reconciliation and the paused scheduler remain outside this local sprint.

Follow [HANDOFF](HANDOFF.md) for preserved rollout constraints and [skipped-work handoff](skipped-work-handoff.md) for dependency order. These are separately scoped future work, not another serial review of completed repairs.

## Budget and authority

Approved September20: continuous local implementation, focused safety checks, one combined review and one final acceptance cycle. Weekly baseline0%; latest account-wide usage{weekly}%; ceiling50%, with a45% stop target. The account meter is not an exact per-task token bill.

Local commits only. No push, PR publication/merge, deployment, external message or scheduler/state change. User-owned `output/` is preserved.
'''
(audit/'fix-plan.md').write_text(plan)
handoff=f'''# Repair sprint handoff

Local repair work is complete on `codex/audit-fixes` at `{rev}`. No further step-by-step repair batches are queued. See [final checkpoint](final-repair-checkpoint.json) for passing checks and precise revision reuse, [fix plan](fix-plan.md) for scope, and [acceptance](acceptance-closure.json) for remaining criteria.

## Current disposition

{c['verified']} verified /{c['partial']} partial /{c['deferred']} deferred /0 pending of322 claims. Saved PRs:242 closed/59 open/0 unreviewed of301. Historical skips:8 verified/1 partial/49 deferred of58. Every saved PR statement is dispositioned; source refreshes retain old hashes. Open means an exact owner, future-consumer or external prerequisite remains; it does not automatically mean a new defect.

Complete Chromium suites:769 passed against optimized production, and769 passed against the unminified coverage build. All unchanged combined coverage gates pass. Actual local image lifecycle checks pass. The API broad run's two timing-fixture failures are resolved by the103-case focused rerun; new boundary cases pass separately. Overlapping runs are not added. Earlier failed logs remain archived alongside successful reruns.

## Preserve completed work

Reuse source-bound authentication, profiles, CRM, finance, notification, UI, database, operations and loop reviews in [step evidence](evidence/step-reviews.json). Read the active documents first; do not routinely reread the historical archive or rebuild verified workflows.

- Apply migrations through0134 before API traffic. Reconcile legacy electricity identities and nonnegative limits before seed/constraint validation. Historical traces stay NULL. Published image tags and production seed remain separate evidence.
- Do not charge DRAFT orders: the real submission caller remains a future consumer. Refund/order/contract/document workflows and legacy invoice/reversal constraint validation keep their recorded prerequisites.
- Notifications require coordinated migrations/workers, published templates/mappings and retirement of old writers. Reminder pools need at least2 connections. Follow [delivery recovery](../docs/operations/notification-delivery-recovery.md) and [template seeding](../docs/operations/notification-template-seeding.md). No historical backfill/resend or live send is authorized.
- Ship storage API/helpers together; allow If-None-Match in bucket CORS, drain old writers and expire old PUT URLs for at least1hour. Reconcile deployed lifecycle/MinIO multipart settings. Real bucket/elapsed-day expiry and future scanner/quarantine/document consumers remain unverified. Manual hold changes must not race classification; independent hold authority needs provider Object Lock.
- Ship web/proxy cache changes together. Production TLS/firewall/load, off-server backups, secrets, installed schedules, recovery exercises and delivered alerts remain unverified. Scheduler and PR304 remain untouched.

## Decisions and future work

The six already-recorded owner questions remain in [progress](progress.json): recovery policy, signed callback CSRF wording, native CSP-report exception,38 base-column deviations, Node24 requirement and Base UI requirement. Preserve them; do not repeatedly reask or silently approve them.

Retain Vite SPA/ADR004, supported manual identity verification, approved pre-login CSRF and the September13 limited trusted server-side secret uses. Dependency license restrictions are waived. Ticket categories are General/Billing/Orders. Support contacts remain info@barghsa.com,021-26658042,09002550292. Auth initial-load150KB and estimator900KB are separately measured; other numeric budgets and coverage floors are unchanged.

[Skipped-work handoff](skipped-work-handoff.md) orders the remaining49 deferred historical claims by dependencies. Partial claims separately retain actual future consumers, manual IDE proof, infrastructure and operations requirements. No provider, deployment or scheduled-exercise success is implied by local checks.

## Continuing efficiently

Start only from a concrete remaining criterion. Use focused tests for edits, reuse matching source-bound evidence, and consolidate review/validation. Keep full API/worker setup builds separate from consumers in the same checkout, and never edit source/tests while their checks run. Preserve complete logs with concise summaries. Use RTK and the codebase graph when available.

Authority remains local edits and explicit commits. No push, PR publication/merge, deployment, scheduler/state change, external message or PR304 action. Preserve untracked user-owned `output/`. Latest account meter:{weekly}% weekly used, below the50% ceiling.
'''
(audit/'HANDOFF.md').write_text(handoff)
print('Wrote concise completion plan and handoff')
