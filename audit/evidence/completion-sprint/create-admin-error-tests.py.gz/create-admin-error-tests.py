from pathlib import Path
names=['AdminTosPage','AdminContractTemplatesPage','AdminEmailProvidersPage','AdminBrandingConfig','AdminStaffTeamsPage','AdminStaffUsersPage','AdminCataloguePage','AdminRolesPage','AdminGiftCodesPage','AdminSmsProvidersPage','AdminFailedJobsPage','AdminApprovalRequestsPage','AdminKnowledgeBasesPage','AdminVerificationConfig','AdminAiModelsPage','AdminAiAgentsPage','AdminGeographyPage','AdminNotificationsPage']
imports=[]
for name in names:
 s=(Path('apps/web/src/pages')/(name+'.tsx')).read_text()
 imports.append(f"import {name} from './{name}.js';" if 'export default' in s else f"import {{ {name} }} from './{name}.js';")
code='''import { act, type ComponentType } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
'''+ '\n'.join(imports)+'''
vi.mock('../hooks/useTimezone.js', () => ({ useTimezone: () => ({ status: 'ready', timezone: 'UTC', retry: () => {} }) }));
let host: HTMLDivElement;
let root: Root;
beforeEach(() => {
  vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT', true);
  host = document.createElement('div');
  document.body.append(host);
  root = createRoot(host);
});
afterEach(async () => {
  await act(async () => root.unmount());
  host.remove();
  vi.unstubAllGlobals();
  document.documentElement.lang = 'en';
});
const pages: Array<[string, ComponentType]> = [
'''+',\n'.join(f"  ['{name}', {name}]" for name in names)+'''
];
for (const locale of ['en', 'fa']) {
  for (const failure of [403, 503, 'network'] as const) {
    it.each(pages)(`%s makes ${failure} reads visible without sending a mutation (${locale})`, async (_name, Page) => {
      document.documentElement.lang = locale;
      const requests = vi.fn(async () => {
        if (failure === 'network') throw new Error('offline');
        return new Response(JSON.stringify({ message: 'Unavailable' }), { status: failure });
      });
      vi.stubGlobal('fetch', requests);
      await act(async () => root.render(<Page />));
      await act(async () => { await Promise.resolve(); await Promise.resolve(); });
      expect(requests).toHaveBeenCalled();
      const alerts = Array.from(host.querySelectorAll('[role=alert]'));
      expect(alerts.length).toBeGreaterThan(0);
      expect(alerts.some((alert) => Boolean(alert.textContent?.trim()))).toBe(true);
      for (const call of vi.mocked(fetch).mock.calls) expect(call[1]?.method ?? 'GET').toBe('GET');
      expect(host.querySelector('[role=dialog]')).toBeNull();
    });
  }
}
'''
Path('apps/web/src/pages/admin-load-errors.test.tsx').write_text(code)
